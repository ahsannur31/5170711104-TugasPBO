package main;


public class Main {

 
    public static void main(String[] args) {
       Manusia man = new Manusia();
       tingkahlaku ting = new tingkahlaku();
       kebutuhan butuh = new kebutuhan ();
       
       man.bergerak();
       ting.bergerak();
       butuh.bergerak();
    }
    
}
