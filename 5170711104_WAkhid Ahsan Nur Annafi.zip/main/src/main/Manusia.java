
package main;

public class Manusia {
     //overriden method
 void bergerak(){
  System.out.println("Manusia bergerak!");
 }
}
