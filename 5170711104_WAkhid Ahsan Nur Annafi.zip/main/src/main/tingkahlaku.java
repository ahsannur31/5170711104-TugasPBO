package main;


public class tingkahlaku extends Manusia {

 @Override
 protected void bergerak(){
  System.out.println("Manusia Jalan");
 }
}
