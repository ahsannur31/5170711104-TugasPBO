
package main;

public class Manusia {
 void bergerak(){
  System.out.println("Manusia bergerak!");
 }
}
