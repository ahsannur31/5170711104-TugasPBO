
package main;


public class kebutuhan extends Manusia {
    
 @Override
 protected void bergerak(){
  System.out.println("Manusia Makan");
 }
}
